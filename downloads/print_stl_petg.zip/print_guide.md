# สายพานคัดแยกคุณภาพเนื้อ — Print guide (Bambu Lab A1, Bambu PETG Basic)
Settings: 0.20 mm, 4 walls, 30 % gyroid (mounts 40 %), nozzle ≈ 255 °C, bed 70 °C (Textured PEI).

| File | Qty | Orientation | Supports | Note |
|---|---|---|---|---|
