import os
import unittest

import numpy as np

from meatqa import analysis, simulate

CFG = analysis.load_config(os.path.join(os.path.dirname(__file__), '..', 'config.json'))


class TestSynthetic(unittest.TestCase):
    def test_marbling_error(self):
        rows = []
        for fat in (0.0, 2.0, 6.0, 10.0, 15.0, 22.0):
            errs = []
            for seed in range(3):
                fr, truth = simulate.make_tray_frames(CFG, fat_pct=fat, seed=seed)
                rec, _ = analysis.analyze_tray(fr, CFG)
                errs.append(rec['marbling']['percent'] - truth['true_fat_fraction'])
            rows.append((fat, float(np.mean(errs)), float(np.max(np.abs(errs)))))
        print('\nsynthetic marbling (true % → mean error, max |error|, percentage points):')
        for r in rows:
            print(f'  {r[0]:5.1f}  {r[1]:+5.2f}  {r[2]:5.2f}')
        self.assertTrue(all(r[2] < 2.0 for r in rows), rows)

    def test_gray_card_removes_colour_cast(self):
        fr0, _ = simulate.make_tray_frames(CFG, fat_pct=8.0, seed=5)
        fr1, _ = simulate.make_tray_frames(CFG, fat_pct=8.0, seed=5, cast=(0.80, 1.0, 1.15))      # cast of the lights
        r0, _ = analysis.analyze_tray(fr0, CFG)
        r1, _ = analysis.analyze_tray(fr1, CFG)
        for k in ('L', 'a', 'b'):
            self.assertLess(abs(r0['lean'][k] - r1['lean'][k]), 3.0, (k, r0['lean'], r1['lean']))
        self.assertAlmostEqual(r0['marbling']['percent'], r1['marbling']['percent'], delta=1.5)

    def test_spoiled_is_flagged_browner(self):
        ok, _ = simulate.make_tray_frames(CFG, fat_pct=8.0, seed=7, spoil=0.0)
        bad, _ = simulate.make_tray_frames(CFG, fat_pct=8.0, seed=7, spoil=1.0)
        r_ok, _ = analysis.analyze_tray(ok, CFG)
        r_bad, _ = analysis.analyze_tray(bad, CFG)
        self.assertLess(r_bad['lean']['a'], r_ok['lean']['a'] - 5)
        self.assertGreater(r_bad['lean']['discolor_fraction'], r_ok['lean']['discolor_fraction'])

    def test_lighting_qc_fails_when_dark(self):
        fr, _ = simulate.make_tray_frames(CFG, fat_pct=8.0, seed=1)
        fr['W'] = (fr['W'].astype(np.float32) * 0.45).astype(np.uint8)
        rec, _ = analysis.analyze_tray(fr, CFG)
        self.assertIn('lighting', ' '.join(rec['reasons']) + str(rec['qc']))

    def test_frame_clipping_flag(self):
        fr, _ = simulate.make_tray_frames(CFG, fat_pct=8.0, seed=2)
        fr['W'][:, :200] = fr['W'][:, 400:600].mean(axis=(0, 1))                                    # smear
        rec, _ = analysis.analyze_tray(fr, CFG)
        self.assertIn('clipped_by_frame', rec)


if __name__ == '__main__':
    unittest.main()
