"""Synthetic tray images with a KNOWN fat percentage — used to test the pipeline and the end-to-end station loop without hardware.
These images only prove the code works; they say nothing about accuracy on real meat (USER_UNVALIDATED)."""
import math
import queue
import time

import cv2
import numpy as np


def _lab_img(L, a, b):
    lab = np.stack([L, a, b], -1).astype(np.float32)
    return np.clip(cv2.cvtColor(lab, cv2.COLOR_LAB2BGR) * 255.0, 0, 255).astype(np.uint8)


def make_tray_frames(cfg, fat_pct=8.0, spoil=0.0, seed=0, cast=(1.0, 1.0, 1.0), nir=True, uv=True, film_hue=330.0):
    """Returns ({'W','NIR','UV'}, truth). `cast` multiplies B,G,R (simulates a colour cast of the lights)."""
    rng = np.random.default_rng(seed)
    W, H = cfg['camera']['width'], cfg['camera']['height']
    L = np.full((H, W), 30.0, np.float32); a = np.full((H, W), 8.0, np.float32); b = np.full((H, W), -30.0, np.float32)    # blue belt
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    # steak: rotated ellipse
    cx, cy = 650 + rng.integers(-30, 30), 360 + rng.integers(-10, 10)
    ax, ay, ang = 285, 240, math.radians(rng.integers(0, 180))
    xr = (xx - cx) * math.cos(ang) + (yy - cy) * math.sin(ang)
    yr = -(xx - cx) * math.sin(ang) + (yy - cy) * math.cos(ang)
    ell = (xr / ax) ** 2 + (yr / ay) ** 2 < 1.0
    # fat = smooth noise thresholded at the quantile that gives exactly fat_pct of the steak area
    noise = cv2.GaussianBlur(rng.standard_normal((H, W)).astype(np.float32), (0, 0), 6)
    thr = np.quantile(noise[ell], 1.0 - fat_pct / 100.0) if fat_pct > 0 else 1e9
    fat = ell & (noise >= thr)
    lean = ell & ~fat
    Ll, al, bl = 36.0, 32.0 - 14.0 * spoil, 18.0 - 3.0 * spoil
    L[lean], a[lean], b[lean] = Ll, al, bl
    L[fat], a[fat], b[fat] = 80.0, 2.0, 10.0
    # tiles + film swatch
    for name, Lt in (('white', 92.0), ('gray', 49.5)):
        x0, y0, x1, y1 = cfg['rois'][name]
        L[int(y0):int(y1), int(x0):int(x1)], a[int(y0):int(y1), int(x0):int(x1)], b[int(y0):int(y1), int(x0):int(x1)] = Lt, 0.0, 0.0
    x0, y0, x1, y1 = cfg['rois']['film']
    L[int(y0):int(y1), int(x0):int(x1)] = 45.0
    a[int(y0):int(y1), int(x0):int(x1)] = 30.0 * math.cos(math.radians(film_hue))
    b[int(y0):int(y1), int(x0):int(x1)] = 30.0 * math.sin(math.radians(film_hue))
    # illumination gradient, sensor noise, a few specular pixels
    L *= (0.94 + 0.12 * (xx / W))
    L += rng.normal(0, 1.2, L.shape).astype(np.float32); a += rng.normal(0, 0.8, a.shape).astype(np.float32); b += rng.normal(0, 0.8, b.shape).astype(np.float32)
    sp = ell & (rng.random((H, W)) < 0.0008)
    L[sp], a[sp], b[sp] = 98.0, 0.0, 0.0
    bgr = _lab_img(L, a, b).astype(np.float32) * np.array(cast, np.float32)[None, None, :]
    frames = {'W': np.clip(bgr, 0, 255).astype(np.uint8)}
    if nir:
        g = np.full((H, W), 55.0, np.float32); g[lean] = 90.0; g[fat] = 170.0; g += rng.normal(0, 3, g.shape).astype(np.float32)
        frames['NIR'] = np.clip(g, 0, 255).astype(np.uint8)
    if uv:
        g = np.full((H, W), 6.0, np.float32); g[ell] = 20.0 + 70.0 * spoil; g += rng.normal(0, 2, g.shape).astype(np.float32)
        frames['UV'] = np.clip(g, 0, 255).astype(np.uint8)
    return frames, {'fat_pct': fat_pct, 'true_fat_fraction': float(fat.sum() / ell.sum() * 100.0), 'spoil': spoil}


class FakeLink:
    """Plays the ESP32: answers commands and emits the event sequence for N trays (so run_station can be tested end to end)."""

    def __init__(self, n_trays=3):
        self.q = queue.Queue()
        self.n = n_trays
        self.sent = []
        self.k = 0
        self.q.put({'ev': 'boot'})

    def send(self, cmd):
        self.sent.append(cmd)
        u = cmd.upper()
        if u.startswith('RUN') and self.k < self.n:
            self.k += 1
            self.q.put({'ev': 'at_cam', 'id': self.k})
        elif u == 'NEXT':
            self.q.put({'ev': 'sensors', 'id': self.k, 't_obj': 3.4 + 0.2 * self.k, 't_amb': 22.0, 'mq137_raw': 600 + 5 * self.k,
                        'as': [120, 340, 560, 800, 1500, 1900, 2300, 2100, 6200, 900]})
            self.q.put({'ev': 'tray_done', 'id': self.k, 'cam_timeout': 0})
            if self.k < self.n:
                self.k += 1
                self.q.put({'ev': 'at_cam', 'id': self.k})

    def get_event(self, timeout=1.0):
        try:
            return self.q.get(timeout=timeout)
        except queue.Empty:
            return None


class FakeCamera:
    fake = True

    """Delivers synthetic frames; the band is whatever the last 'LED <ch> 255' command selected (set by the station through `band`)."""

    def __init__(self, cfg, fat_list=(3.0, 8.0, 14.0), seed=1):
        self.cfg, self.fat_list, self.seed, self.i, self.band = cfg, list(fat_list), seed, -1, 'W'
        self.cache = None

    def new_tray(self):
        self.i += 1
        fat = self.fat_list[self.i % len(self.fat_list)]
        self.cache, self.truth = make_tray_frames(self.cfg, fat_pct=fat, seed=self.seed + self.i, spoil=0.15 * (self.i % 3))

    def grab(self, band):
        return self.cache[band]
