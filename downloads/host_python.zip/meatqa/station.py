"""Station loop: ESP32 (serial JSON lines) + USB webcam → analysis → CSV / images / HTML. Hardware parts are untested on a real belt."""
import csv
import json
import os
import queue
import threading
import time

import cv2
import numpy as np

from . import analysis


class SerialLink:
    def __init__(self, port, baud=115200):
        import serial
        self.ser = serial.Serial(port, baud, timeout=0.2)
        self.q = queue.Queue()
        self._stop = False
        threading.Thread(target=self._reader, daemon=True).start()

    def _reader(self):
        buf = b''
        while not self._stop:
            try:
                buf += self.ser.read(256)
            except Exception:
                break
            while b'\n' in buf:
                line, buf = buf.split(b'\n', 1)
                line = line.strip()
                if line.startswith(b'{'):
                    try:
                        self.q.put(json.loads(line))
                    except Exception:
                        pass

    def send(self, cmd):
        self.ser.write((cmd.strip() + '\n').encode())

    def get_event(self, timeout=1.0):
        try:
            return self.q.get(timeout=timeout)
        except queue.Empty:
            return None

    def close(self):
        self._stop = True
        self.ser.close()


class Camera:
    """USB webcam. Exposure / white balance must be LOCKED (UVC control app or OS settings) — OpenCV properties are best effort only."""

    def __init__(self, cfg):
        c = cfg['camera']
        self.cfg = cfg
        self.cap = cv2.VideoCapture(c['index'])
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, c['width'])
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, c['height'])
        self.cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.25)      # manual on most V4L2 drivers
        self.cap.set(cv2.CAP_PROP_AUTO_WB, 0)

    def grab(self, band=None):
        c = self.cfg['camera']
        for _ in range(c['discard_frames']):
            self.cap.read()
        acc = None
        for _ in range(c['frames_per_band']):
            ok, f = self.cap.read()
            if not ok:
                raise RuntimeError('camera read failed')
            acc = f.astype(np.float32) if acc is None else acc + f.astype(np.float32)
        return np.clip(acc / c['frames_per_band'], 0, 255).astype(np.uint8)


def capture_bands(link, cam, cfg, plus=True):
    """White → NIR 850 → UV 365, one band lit at a time. With a fake camera the band name selects the synthetic frame."""
    frames = {}
    for band in (('W', 'NIR', 'UV') if plus else ('W',)):
        link.send('ALLOFF')
        link.send(f'LED {band} 255')
        time.sleep(cfg['camera']['settle_s'] if not hasattr(cam, 'fake') else 0)
        frames[band] = cam.grab(band)
    link.send('ALLOFF')
    return frames


CSV_COLS = ['time', 'tray_id', 'status', 'reasons', 'marbling_pct', 'marbling_grade', 'lean_L', 'lean_a', 'lean_b', 'lean_hue', 'discolor_fraction',
            'film_hue', 'film_state', 'meat_area_mm2', 'clipped_by_frame', 'lighting_ok', 'nir_contrast', 'uv_fluor', 't_obj_C', 't_amb_C', 'mq137_raw',
            'red_over_green']


def flat_row(tid, rec):
    lean = rec.get('lean', {})
    sens = rec.get('sensors', {})
    return {'time': time.strftime('%Y-%m-%d %H:%M:%S'), 'tray_id': tid, 'status': rec['status'], 'reasons': '; '.join(rec['reasons']),
            'marbling_pct': rec['marbling']['percent'], 'marbling_grade': rec['marbling']['grade'],
            'lean_L': lean.get('L'), 'lean_a': lean.get('a'), 'lean_b': lean.get('b'), 'lean_hue': lean.get('hue_deg'),
            'discolor_fraction': lean.get('discolor_fraction'), 'film_hue': rec['film']['hue_deg'], 'film_state': rec['film']['state'],
            'meat_area_mm2': rec['meat_area_mm2'], 'clipped_by_frame': rec['clipped_by_frame'], 'lighting_ok': rec['qc']['lighting_ok'],
            'nir_contrast': rec['bands'].get('NIR', {}).get('fat_lean_contrast'), 'uv_fluor': rec['bands'].get('UV', {}).get('fluor_fraction'),
            't_obj_C': sens.get('t_obj_C'), 't_amb_C': sens.get('t_amb_C'), 'mq137_raw': sens.get('mq137_raw'), 'red_over_green': sens.get('red_over_green')}


def run_station(link, cam, cfg, outdir, max_trays=None, plus=True, wait_s=60.0, on_tray=None):
    os.makedirs(outdir, exist_ok=True)
    csv_path = os.path.join(outdir, 'results.csv')
    new = not os.path.exists(csv_path)
    f = open(csv_path, 'a', newline='', encoding='utf-8-sig')
    w = csv.DictWriter(f, fieldnames=CSV_COLS)
    if new:
        w.writeheader()
    pending = {}
    done = 0
    link.send('RUN')
    t_last = time.time()
    while max_trays is None or done < max_trays:
        ev = link.get_event(timeout=1.0)
        if ev is None:
            if time.time() - t_last > wait_s:
                print('no event for', wait_s, 's — stopping')
                break
            continue
        t_last = time.time()
        kind = ev.get('ev')
        if kind == 'at_cam':
            tid = ev['id']
            if hasattr(cam, 'new_tray'):
                cam.new_tray()
            frames = capture_bands(link, cam, cfg, plus)
            rec, ann = analysis.analyze_tray(frames, cfg)
            d = os.path.join(outdir, f'tray_{tid:04d}')
            os.makedirs(d, exist_ok=True)
            for k, v in frames.items():
                cv2.imwrite(os.path.join(d, f'{k}.png'), v)
            cv2.imwrite(os.path.join(d, 'annotated.png'), ann)
            pending[tid] = (rec, frames, d)
            link.send('NEXT')
        elif kind == 'sensors':
            tid = ev['id']
            if tid in pending:
                rec, frames, d = pending[tid]
                rec['sensors'] = analysis.spectral_features(ev.get('as'), ev.get('mq137_raw'), ev.get('t_obj'), ev.get('t_amb'))
                rec['status'], rec['reasons'] = analysis.status_rules(rec, cfg)
                json.dump(rec, open(os.path.join(d, 'record.json'), 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
                w.writerow(flat_row(tid, rec)); f.flush()
                done += 1
                print(f"tray {tid}: marbling {rec['marbling']['percent']}% ({rec['marbling']['grade']}, not validated) status={rec['status']} {rec['reasons']}")
                if on_tray:
                    on_tray(tid, rec)
        elif kind == 'error':
            print('ESP32 error:', ev.get('msg'))
    link.send('STOP')
    f.close()
    return csv_path
