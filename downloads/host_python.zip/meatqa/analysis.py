"""Meat inspection image analysis (screening aid — NOT a food-safety test, thresholds are placeholders: USER_UNVALIDATED).

Input  : colour frame under cross-polarized white light (+ optional NIR 850 nm and UV 365 nm frames, AS7341 / MLX90614 / MQ-137 readings)
Output : per-tray record (marbling %, lean colour L*a*b*, discoloration, film-indicator colour, spectral ratios, temperature, status) + annotated image

Colour reference: an 18 % gray card and a white tile sit in the field of view next to the belt (ROIs in config.json). The gray card sets the
per-channel gain in LINEAR light; the white tile is only a quality check (lighting clipped / too dark).
"""
import json
import math
import os

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
RULES_VERSION = 'v0-placeholder (USER_UNVALIDATED)'


def load_config(path=None):
    path = path or os.path.join(HERE, '..', 'config.json')
    with open(path, encoding='utf-8') as f:
        return json.load(f)


# ---------------------------------------------------------------- colour helpers
def srgb_to_linear(u8):
    x = u8.astype(np.float32) / 255.0
    return np.where(x <= 0.04045, x / 12.92, ((x + 0.055) / 1.055) ** 2.4).astype(np.float32)


def linear_to_srgb_u8(lin):
    lin = np.clip(lin, 0, 1)
    x = np.where(lin <= 0.0031308, lin * 12.92, 1.055 * np.power(lin, 1 / 2.4) - 0.055)
    return np.clip(np.rint(x * 255.0), 0, 255).astype(np.uint8)


def to_lab(bgr_u8):
    """OpenCV float Lab: L 0..100, a/b about -128..127."""
    return cv2.cvtColor(bgr_u8.astype(np.float32) / 255.0, cv2.COLOR_BGR2LAB)


def roi_slice(roi):
    x0, y0, x1, y1 = roi
    return slice(int(y0), int(y1)), slice(int(x0), int(x1))


def gray_card_correct(bgr, gray_roi, white_roi, cfg):
    """Per-channel gain so that the 18 % gray card reads 0.18 in linear light. Returns (corrected_bgr, qc dict)."""
    lin = srgb_to_linear(bgr)
    g = lin[roi_slice(gray_roi)].reshape(-1, 3).mean(0)             # B, G, R
    gain = cfg['gray_card_reflectance'] / np.maximum(g, 1e-4)
    out = lin * gain[None, None, :]
    corrected = linear_to_srgb_u8(out)
    w = to_lab(corrected)[roi_slice(white_roi)][..., 0].mean()
    qc = {'gray_gain_bgr': [round(float(x), 3) for x in gain], 'white_tile_L': round(float(w), 1), 'lighting_ok': bool(cfg['white_L_min'] <= w <= cfg['white_L_max'])}
    if gain.max() / gain.min() > cfg['max_gain_ratio']:
        qc['lighting_ok'] = False
        qc['warning'] = 'gray-card channel gains differ a lot — check white balance lock / lighting'
    return corrected, qc


# ---------------------------------------------------------------- segmentation
def _largest_component(mask_u8):
    n, lab, stats, _ = cv2.connectedComponentsWithStats(mask_u8, connectivity=8)
    if n <= 1:
        return np.zeros_like(mask_u8)
    k = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    return (lab == k).astype(np.uint8)


def _fill_holes(mask_u8):
    h, w = mask_u8.shape
    ff = mask_u8.copy()
    pad = np.zeros((h + 2, w + 2), np.uint8)
    cv2.floodFill(ff, pad, (0, 0), 1)
    return (mask_u8 | (1 - ff)).astype(np.uint8)


def meat_mask(lab, cfg, exclude_rois=()):
    """Meat = inside the meat ROI, not belt-blue, not too dark, not a reference tile. Largest blob, holes filled."""
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    m = np.zeros(L.shape, np.uint8)
    x0, y0, x1, y1 = cfg['rois']['meat']
    m[int(y0):int(y1), int(x0):int(x1)] = 1
    m &= ((b > cfg['belt_b_max']) & (L > cfg['min_L'])).astype(np.uint8)
    for r in exclude_rois:
        m[roi_slice(r)] = 0
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, k)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
    m = _fill_holes(_largest_component(m))
    return m.astype(bool)


def fat_lean(lab, mask, cfg):
    """Split meat pixels into lean (red, high a*) and fat (pale, low a*, high L*). Returns lean, fat, glare, a_threshold."""
    L, a, b = lab[..., 0], lab[..., 1], lab[..., 2]
    chroma = np.hypot(a, b)
    glare = mask & (L > cfg['glare_L']) & (chroma < cfg['glare_chroma'])
    use = mask & ~glare
    av = a[use]
    if av.size < 500:
        return np.zeros_like(mask), np.zeros_like(mask), glare, float('nan')
    scaled = np.clip((av + 10.0) * (255.0 / 70.0), 0, 255).astype(np.uint8)
    t, _ = cv2.threshold(scaled.reshape(-1, 1), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    a_thr = float(t) * 70.0 / 255.0 - 10.0
    hi, lo = av[av > a_thr], av[av <= a_thr]
    if hi.size == 0 or lo.size == 0 or (hi.mean() - lo.mean()) < cfg['min_class_gap_a']:
        a_thr = cfg['a_thr_default']                                   # unimodal: almost no fat, use a fixed lean/fat split
    a_thr = float(np.clip(a_thr, cfg['a_thr_min'], cfg['a_thr_max']))
    lean = use & (a > a_thr)
    fat = use & (a <= a_thr) & (L > cfg['fat_min_L'])
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    fat = cv2.morphologyEx(fat.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool)
    return lean, fat, glare, a_thr


def grade_marbling(pct, cfg):
    edges = cfg['marbling_grade_edges']
    names = cfg['marbling_grade_names']
    for e, n in zip(edges, names):
        if pct < e:
            return n
    return names[-1]


# ---------------------------------------------------------------- per-band / sensor features
def band_features(gray, mask, lean, fat, cfg, kind):
    g = gray.astype(np.float32)
    if g.ndim == 3:
        g = g.mean(2)
    vals = g[mask]
    if vals.size == 0:
        return {'mean': None}
    out = {'mean': round(float(vals.mean()), 1), 'p10': round(float(np.percentile(vals, 10)), 1), 'p90': round(float(np.percentile(vals, 90)), 1)}
    out['dark'] = bool(vals.mean() < cfg['band_min_mean'])             # e.g. the webcam IR-cut filter removes the NIR band
    if kind == 'NIR' and lean.any() and fat.any():
        out['fat_lean_contrast'] = round(float((g[fat].mean() - g[lean].mean()) / max(g[lean].mean(), 1.0)), 3)
    if kind == 'UV':
        out['fluor_fraction'] = round(float((vals > cfg['uv_fluor_thr']).mean()), 4)
    return out


def film_reading(bgr_corrected, cfg):
    """pH-indicator film swatch (red-cabbage anthocyanin): mean Lab + hue. The hue→state table comes from YOUR calibration (config 'film_table')."""
    roi = cfg['rois']['film']
    patch = bgr_corrected[roi_slice(roi)]
    lab = to_lab(patch).reshape(-1, 3).mean(0)
    hue = (math.degrees(math.atan2(lab[2], lab[1])) + 360.0) % 360.0
    rec = {'L': round(float(lab[0]), 1), 'a': round(float(lab[1]), 1), 'b': round(float(lab[2]), 1), 'hue_deg': round(hue, 1), 'state': None}
    for row in cfg.get('film_table', []):
        if row['hue_min'] <= hue <= row['hue_max']:
            rec['state'] = row['label']
    return rec


def spectral_features(as10, mq_raw, t_obj, t_amb):
    """AS7341 [F1 415, F2 445, F3 480, F4 515, F5 555, F6 590, F7 630, F8 680, Clear, NIR] → ratios to Clear (illumination-normalised)."""
    out = {'t_obj_C': t_obj, 't_amb_C': t_amb, 'mq137_raw': mq_raw}
    if as10 and len(as10) == 10 and as10[8] > 0:
        clear = float(as10[8])
        out['as7341_norm'] = [round(v / clear, 4) for v in as10]
        out['red_over_green'] = round(as10[6] / max(as10[3], 1), 3)      # 630 / 515 nm — drops when the surface browns (hypothesis)
    return out


# ---------------------------------------------------------------- status rules (placeholder)
def status_rules(rec, cfg):
    r = cfg['rules']
    reasons, level = [], 0
    t = rec.get('sensors', {}).get('t_obj_C')
    if t is not None and not (isinstance(t, float) and math.isnan(t)):
        if t >= r['t_obj_alarm']:
            reasons.append(f'surface {t:.1f} °C ≥ {r["t_obj_alarm"]}'); level = max(level, 2)
        elif t >= r['t_obj_watch']:
            reasons.append(f'surface {t:.1f} °C ≥ {r["t_obj_watch"]}'); level = max(level, 1)
    d = rec.get('lean', {}).get('discolor_fraction')
    if d is not None:
        if d >= r['disc_alarm']:
            reasons.append(f'discoloration {d:.0%}'); level = max(level, 2)
        elif d >= r['disc_watch']:
            reasons.append(f'discoloration {d:.0%}'); level = max(level, 1)
    a = rec.get('lean', {}).get('a')
    if a is not None and a < r['lean_a_min_watch']:
        reasons.append(f'lean a* {a:.1f} low (pale/brown)'); level = max(level, 1)
    fs = rec.get('film', {}).get('state')
    if fs and fs in r.get('film_alarm_states', []):
        reasons.append(f'film indicator: {fs}'); level = max(level, 2)
    if not rec['qc']['lighting_ok']:
        reasons.append('lighting QC failed — result unreliable'); level = max(level, 1)
    return ['ok', 'watch', 'alarm'][level], reasons


# ---------------------------------------------------------------- main entry
def analyze_tray(frames, cfg, sensors=None):
    """frames: {'W': bgr uint8 (required), 'NIR': gray/bgr (optional), 'UV': bgr (optional)}. Returns (record, annotated_bgr)."""
    bgr = frames['W']
    rois = cfg['rois']
    corrected, qc = gray_card_correct(bgr, rois['gray'], rois['white'], cfg)
    lab = to_lab(corrected)
    mask = meat_mask(lab, cfg, exclude_rois=(rois['white'], rois['gray'], rois['film']))
    lean, fat, glare, a_thr = fat_lean(lab, mask, cfg)
    px_mm = cfg['px_per_mm']
    area_mm2 = float(mask.sum()) / (px_mm * px_mm)
    n_fat, n_lean = int(fat.sum()), int(lean.sum())
    marb = 100.0 * n_fat / max(n_fat + n_lean, 1)
    rec = {'qc': qc, 'meat_area_mm2': round(area_mm2, 1), 'a_threshold': None if math.isnan(a_thr) else round(a_thr, 2), 'glare_fraction': round(float(glare.sum()) / max(int(mask.sum()), 1), 4)}
    touches = bool(mask[0, :].any() or mask[-1, :].any() or mask[:, 0].any() or mask[:, -1].any())
    rec['clipped_by_frame'] = touches                                  # the piece is larger than the field of view → marbling % is partial
    rec['marbling'] = {'percent': round(marb, 2), 'grade': grade_marbling(marb, cfg), 'grade_validated': False}
    if lean.any():
        ll = lab[lean]
        a, b = ll[:, 1], ll[:, 2]
        ratio = a / np.maximum(b, 1.0)
        rec['lean'] = {'L': round(float(ll[:, 0].mean()), 2), 'a': round(float(a.mean()), 2), 'b': round(float(b.mean()), 2),
                       'chroma': round(float(np.hypot(a, b).mean()), 2), 'hue_deg': round(float(math.degrees(math.atan2(b.mean(), a.mean()))), 1),
                       'a_over_b': round(float(ratio.mean()), 3), 'discolor_fraction': round(float((ratio < cfg['browning_ratio']).mean()), 4)}
    else:
        rec['lean'] = {}
    rec['film'] = film_reading(corrected, cfg)
    bands = {}
    for kind in ('NIR', 'UV'):
        if frames.get(kind) is not None:
            bands[kind] = band_features(frames[kind], mask, lean, fat, cfg, kind)
    rec['bands'] = bands
    if sensors:
        rec['sensors'] = spectral_features(sensors.get('as'), sensors.get('mq137_raw'), sensors.get('t_obj'), sensors.get('t_amb'))
    rec['status'], rec['reasons'] = status_rules(rec, cfg)
    rec['rules_version'] = RULES_VERSION
    # annotated picture
    ann = corrected.copy()
    ov = ann.copy()
    ov[fat] = (255, 255, 0)
    ov[glare] = (255, 0, 255)
    ann = cv2.addWeighted(ov, 0.45, ann, 0.55, 0)
    cnts, _ = cv2.findContours(mask.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(ann, cnts, -1, (0, 255, 0), 2)
    for name in ('white', 'gray', 'film'):
        x0, y0, x1, y1 = rois[name]
        cv2.rectangle(ann, (int(x0), int(y0)), (int(x1), int(y1)), (0, 200, 255), 2)
    txt = [f"marbling {rec['marbling']['percent']:.1f}% ({rec['marbling']['grade']}, not validated)", f"status {rec['status']}"]
    for i, t in enumerate(txt):
        cv2.putText(ann, t, (20, 40 + 34 * i), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), 3, cv2.LINE_AA)
        cv2.putText(ann, t, (20, 40 + 34 * i), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 0, 0), 1, cv2.LINE_AA)
    return rec, ann
