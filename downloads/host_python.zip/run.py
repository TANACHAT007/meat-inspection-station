"""Meat inspection station — host program.
  python run.py selftest                      synthetic images with known fat % (pipeline check; says nothing about real accuracy)
  python run.py simulate --n 4 --out out_sim  full station loop with a fake ESP32 + fake camera
  python run.py analyze frame.png [NIR.png UV.png]   analyse one saved white-light frame
  python run.py rois frame.png                click the white tile, gray card, film swatch and meat area, save them to config.json
  python run.py run --port /dev/cu.usbserial-XXXX --camera 0 --out out   the real station
"""
import argparse
import json
import os
import sys

import cv2

from meatqa import analysis, simulate, station

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = os.path.join(HERE, 'config.json')


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest='cmd', required=True)
    sub.add_parser('selftest')
    p = sub.add_parser('simulate'); p.add_argument('--n', type=int, default=4); p.add_argument('--out', default='out_sim')
    p = sub.add_parser('analyze'); p.add_argument('files', nargs='+')
    p = sub.add_parser('rois'); p.add_argument('frame')
    p = sub.add_parser('run'); p.add_argument('--port', required=True); p.add_argument('--camera', type=int, default=0); p.add_argument('--out', default='out'); p.add_argument('--no-plus', action='store_true')
    a = ap.parse_args()
    cfg = analysis.load_config(CFG)
    if a.cmd == 'selftest':
        import unittest
        sys.exit(0 if unittest.main(module='tests.test_analysis', argv=['x'], exit=False).result.wasSuccessful() else 1)
    if a.cmd == 'simulate':
        link, cam = simulate.FakeLink(a.n), simulate.FakeCamera(cfg)
        print('CSV:', station.run_station(link, cam, cfg, a.out, max_trays=a.n, wait_s=5))
    elif a.cmd == 'analyze':
        frames = {'W': cv2.imread(a.files[0])}
        if len(a.files) > 1: frames['NIR'] = cv2.imread(a.files[1], cv2.IMREAD_GRAYSCALE)
        if len(a.files) > 2: frames['UV'] = cv2.imread(a.files[2])
        rec, ann = analysis.analyze_tray(frames, cfg)
        cv2.imwrite('annotated.png', ann)
        print(json.dumps(rec, ensure_ascii=False, indent=1))
    elif a.cmd == 'rois':
        img = cv2.imread(a.frame)
        for name in ('white', 'gray', 'film', 'meat'):
            r = cv2.selectROI(f'select {name} (ENTER to accept)', img, showCrosshair=False)
            if r[2] and r[3]:
                cfg['rois'][name] = [int(r[0]), int(r[1]), int(r[0] + r[2]), int(r[1] + r[3])]
        cv2.destroyAllWindows()
        json.dump(cfg, open(CFG, 'w', encoding='utf-8'), ensure_ascii=False, indent=2)
        print('saved', cfg['rois'])
    elif a.cmd == 'run':
        cfg['camera']['index'] = a.camera
        link = station.SerialLink(a.port)
        cam = station.Camera(cfg)
        try:
            print('CSV:', station.run_station(link, cam, cfg, a.out, plus=not a.no_plus))
        finally:
            link.send('STOP'); link.send('ALLOFF'); link.close()


if __name__ == '__main__':
    main()
